### Hexlet tests and linter status:
[![Actions Status](https://github.com/green4lime/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/green4lime/python-project-49/actions)
<a href="https://codeclimate.com/github/green4lime/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/7e6e3348c3aed1e62dd4/maintainability" /></a>
<a href="https://codeclimate.com/github/green4lime/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/7e6e3348c3aed1e62dd4/test_coverage" /></a>